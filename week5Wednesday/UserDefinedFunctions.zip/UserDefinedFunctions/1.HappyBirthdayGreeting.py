##Function to create a birthday greeting

def createGreeting(name):

    out = "Happy birthday to you!  Happy birthday to you!  Happy birthday dear " +  name
    print(out)


## Main program
#createGreeting("Sam")
