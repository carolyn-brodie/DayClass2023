##Add 5 Function
def addFive(number):
    result = number + 5
    #print(result)
    return result

##addFive(6)
x = addFive(6)
##print(addFive(6))
print(x + 2)
